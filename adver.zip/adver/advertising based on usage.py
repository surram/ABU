
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[2]:



import types
import pandas as pd
from botocore.client import Config
import ibm_boto3

def __iter__(self): return 0

# @hidden_cell
# The following code accesses a file in your IBM Cloud Object Storage. It includes your credentials.
# You might want to remove those credentials before you share your notebook.
client_8b31a171f6d643e0845d5fde3cc22ee3 = ibm_boto3.client(service_name='s3',
    ibm_api_key_id='8NdxEDtBEy0s5ZlH3orB-3S-qxVGLfFT7xytaTZFLfcn',
    ibm_auth_endpoint="https://iam.bluemix.net/oidc/token",
    config=Config(signature_version='oauth'),
    endpoint_url='https://s3.eu-geo.objectstorage.service.networklayer.com')

body = client_8b31a171f6d643e0845d5fde3cc22ee3.get_object(Bucket='advertising-donotdelete-pr-tlr7hctfozysqm',Key='advertising.csv')['Body']
# add missing __iter__ method, so pandas accepts body as file-like object
if not hasattr(body, "__iter__"): body.__iter__ = types.MethodType( __iter__, body )

dataset= pd.read_csv(body)
dataset.head()



# In[3]:


dataset.drop(['Timestamp'],axis=1,inplace=True)


# In[4]:


dataset['City'].value_counts()


# In[5]:


dataset.drop(['Ad Topic Line','City','Country'],axis=1,inplace=True)


# In[6]:


dataset.isnull().any()


# In[7]:


dataset.shape


# In[8]:


dataset


# In[9]:


x=dataset.iloc[:,0:5].values
x


# In[10]:


y=dataset.iloc[:,5:].values
y


# In[11]:


x.shape


# In[12]:


y.shape


# In[13]:


from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


# In[14]:


x_train


# In[15]:


x_test


# In[16]:


x_test.shape


# In[17]:


y_train


# In[18]:


y_test


# In[19]:


from sklearn.preprocessing import StandardScaler
sc=StandardScaler()
x_train=sc.fit_transform(x_train)
x_test=sc.transform(x_test)


# In[20]:


x_train


# # Logistic Regression

# In[21]:


from sklearn.linear_model import LogisticRegression
classifier=LogisticRegression()
classifier.fit(x_train,y_train)


# In[22]:


y_predict=classifier.predict(x_test)
y_predict


# In[23]:


x_test[7]


# In[24]:


classifier.predict([[-1.12641091, -0.47415063, -1.75969764, -0.98622179,  1.06458129]])


# In[25]:


from sklearn.metrics import accuracy_score
accuracy_score(y_test,y_predict)


# In[26]:


from sklearn.metrics import confusion_matrix
cm=confusion_matrix(y_test,y_predict)
cm


# In[27]:


import sklearn.metrics as metrics
fpr,tpr,threshold=metrics.roc_curve(y_test,y_predict)
roc_auc=metrics.auc(fpr,tpr)


# In[28]:


roc_auc


# In[29]:


plt.plot(fpr,tpr)
plt.show()


# In[30]:


plt.plot(fpr,tpr,label='AUC=%0.2f'%roc_auc)
plt.legend()
plt.show()


# In[31]:


get_ipython().system(u'pip install watson-machine-learning-client --upgrade')


# In[32]:


from watson_machine_learning_client import WatsonMachineLearningAPIClient


# In[33]:


wml_credentials={"instance_id": "8e6aa283-c0ed-4750-8eaa-96d64978baf9",
 "password": "8d68aa2c-dc19-4454-b517-45f4b43b5884",
 "url": "https://eu-gb.ml.cloud.ibm.com",
 "username": "b620548d-6f2f-4191-bcf0-7c7357536d14","access_key": "oiqN0CmQ-ik90F-k95rNYDjwTtBUsTZ4FPDCUs3bEogw"}
 


# In[34]:



client=WatsonMachineLearningAPIClient(wml_credentials)


# In[35]:


import json
instance_details=client.service_instance.get_details()
print(json.dumps(instance_details,indent=2))


# In[37]:


model_props={client.repository.ModelMetaNames.AUTHOR_NAME:"shruthi",
             client.repository.ModelMetaNames.AUTHOR_EMAIL:"shruthikannoju27@gmail.com",
             client.repository.ModelMetaNames.NAME:"advertising"}


# In[39]:



model_artifacts=client.repository.store_model(classifier,meta_props=model_props)


# In[40]:



published_model_uid=client.repository.get_model_uid(model_artifacts)


# In[41]:



published_model_uid


# In[44]:


created_deployments=client.deployments.create(published_model_uid,name="advertising")


# In[45]:



scoring_endpoint=client.deployments.get_scoring_url(created_deployments)


# In[46]:



print(scoring_endpoint)


# In[47]:


client.deployments.list()


# # Decisson tree

# In[ ]:


#from sklearn.tree import DecisionTreeClassifier
#classifier= DecisionTreeClassifier(random_state=0,criterion='entropy')
#classifier.fit(x_train,y_train)


# In[ ]:


#y_predict_dt =classifier.predict(x_test)


# In[ ]:


#x_test[0]


# In[ ]:


#x_test[7]


# In[ ]:


#y_predict_dt


# In[ ]:


#classifier.predict([[-1.12641091, -0.47415063, -1.75969764, -0.98622179,  1.06458129]])


# In[ ]:


#from sklearn.metrics import accuracy_score
#accuracy_score(y_test,y_predict_dt)


# In[ ]:


#import sklearn.metrics as metrics
#fpr, tpr, threshold = metrics.roc_curve(y_test, y_predict_dt)
#roc_auc = metrics.auc(fpr, tpr)
#roc_auc


# In[ ]:


#plt.plot(fpr,tpr)
#plt.show()


# In[ ]:


#plt.plot(fpr,tpr,label='AUC=%0.2f'%roc_auc)
#plt.legend()
#plt.show()


# # knn

# In[ ]:


#from sklearn.neighbors import KNeighborsClassifier
#classifier_knn = KNeighborsClassifier(n_neighbors = 5, metric = 'minkowski', p = 2)
#classifier_knn.fit(x_train, y_train)


# In[ ]:


#y_pred_knn = classifier_knn.predict(x_test)


# In[ ]:


#x_test[0]


# In[ ]:


#classifier_knn.predict([[-0.03398248, -1.04199571,  0.83725258,  1.10196897,  1.06458129]])


# In[ ]:


#import sklearn.metrics as metrics
#fpr, tpr, threshold = metrics.roc_curve(y_test, y_pred_knn)
#roc_auc_knn= metrics.auc(fpr, tpr)
#roc_auc_knn


# In[ ]:


#from sklearn.metrics import accuracy_score
#accuracy_score(y_test,y_pred_knn)


# In[ ]:


#plt.plot(fpr,tpr)
#plt.show()


# In[ ]:


# plt.plot(fpr,tpr,label='AUC=%0.2f'%roc_auc)
#plt.legend()
#plt.show()


# # Random Forest

# In[ ]:


#from sklearn.ensemble import RandomForestClassifier
#classifier_rnn=RandomForestClassifier(n_estimators=30,criterion='entropy',random_state=0)


# In[ ]:


#classifier_rnn.fit(x_train,y_train)


# In[ ]:


#y_predict_rnn=classifier_rnn.predict(x_test)
#y_predict_rnn


# In[ ]:


#x_test[7]


# In[ ]:


#classifier_rnn.predict([[-1.12641091, -0.47415063, -1.75969764, -0.98622179,  1.06458129]])


# In[ ]:


#from sklearn.metrics import accuracy_score
#accuracy_score(y_test,y_predict_rnn)


# In[ ]:


#from sklearn.metrics import confusion_matrix
#cm=confusion_matrix(y_test,y_predict_rnn)
#cm
                   


# In[ ]:


#import sklearn.metrics as metrics
#fpr, tpr, threshold = metrics.roc_curve(y_test, y_predict_rnn)
#roc_auc_rnn= metrics.auc(fpr, tpr)
#roc_auc_rnn


# In[ ]:


#plt.plot(fpr,tpr)
#plt.show()


# In[ ]:


#plt.plot(fpr,tpr,label='AUC=%0.2f'%roc_auc)
#plt.legend()
#plt.show()

